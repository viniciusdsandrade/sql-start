create definer = root@localhost trigger TG_CALCULA_FATURAMENTO_DELETE
    after delete
    on itens_notas_fiscais
    for each row
BEGIN
    DELETE FROM TABELA_FATURAMENTO;
    INSERT INTO TABELA_FATURAMENTO
    SELECT A.DATA_VENDA, SUM(B.QUANTIDADE * B.PRECO) AS TOTAL_VENDA
    FROM NOTAS_FISCAIS A
             INNER JOIN ITENS_NOTAS_FISCAIS B
                        ON A.NUMERO = B.NUMERO
    GROUP BY A.DATA_VENDA;
END;

